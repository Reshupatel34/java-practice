public class LeadingTrailing {
    public static void main(String[] args) {
        String str = "   Welcome to Java   ";
        System.out.println("Before trim: '" + str + "'");
        System.out.println("After trim : '" + str.trim() + "'");
    }
}
