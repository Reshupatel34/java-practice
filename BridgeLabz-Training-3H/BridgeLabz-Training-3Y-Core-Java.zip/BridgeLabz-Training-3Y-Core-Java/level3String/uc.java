class Uc {
    public static void main(String[] args) {
        String s = "hello world";
        System.out.println("Uppercase: " + s.toUpperCase());
    }
}
